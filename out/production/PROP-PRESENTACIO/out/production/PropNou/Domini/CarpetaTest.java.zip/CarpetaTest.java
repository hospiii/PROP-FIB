package Domini;

import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

public class CarpetaTest {
    private static Carpeta car1;
    private static String ;


    @BeforeClass

    @Test
    public void getPath() {
    }

    @Test
    public void importa_document() {
    }

    @Test
    public void baixa_Document() {
    }

    @Test
    public void get_titols() {
    }

    @Test
    public void get_autors() {
    }

    @Test
    public void get_contenido() {
    }

    @Test
    public void visualizar_lista() {
    }
}